document.getElementById("inicio").addEventListener("click", function() {
    window.location.href = "inicio.html";
});