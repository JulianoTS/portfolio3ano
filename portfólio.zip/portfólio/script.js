document.getElementById("modelagem").addEventListener("click", function() {
    window.location.href = "modelagem.html";
});

document.getElementById("sistemas").addEventListener("click", function() {
    window.location.href = "sistemas.html";
});

document.getElementById("software").addEventListener("click", function() {
    window.location.href = "software.html";
});
